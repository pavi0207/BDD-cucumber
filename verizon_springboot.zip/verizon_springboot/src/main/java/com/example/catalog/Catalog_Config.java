package com.example.catalog;

public class Catalog_Config {

}
