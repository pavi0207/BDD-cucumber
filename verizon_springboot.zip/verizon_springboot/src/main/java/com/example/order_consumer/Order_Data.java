package com.example.order_consumer;



public class Order_Data {
	//private @Id @GeneratedValue Long id;
	 private int orderid;
	 private String name;
	 
	 public int getOrderId()
	 {
		 return this.orderid;
	 }
	 public String getname()
	 {
		 return this.name;
	 }
	 public void setOrderId(int num){
		 
		 this.orderid = num;
	 }
	 public void setName(String n)
	 {
		 
		 this.name= n;
	 }
}
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
		 
	 
	