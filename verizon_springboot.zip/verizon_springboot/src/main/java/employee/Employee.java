package employee;
import java.util.ArrayList;

import javax.persistence.Entity;

@Entity
public class Employee {

		//private @Id @GeneratedValue Long id;
		 private String name;
		 private int id;
		 public Employee(){}
		 public int getid()
		 {
			 return this.id;
		 }
		 public String getname()
		 {
			 return this.name;
		 }
		 public Employee(String name){
			 
			 this.name = name;
		 }
		 public Employee(int id){
			 
			 this.id = id;
		 }
		 
		 public void test()
		 {
		 
			 System.out.println("Test  Method");
		}

		 public ArrayList<String>getCatalogList()
		 {
			 ArrayList<String> data=new ArrayList<String>();
			 data.add("Clothes");
			 data.add("food");
			return data;
		 }
	

}
