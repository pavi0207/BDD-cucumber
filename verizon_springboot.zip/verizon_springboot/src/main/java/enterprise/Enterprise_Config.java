package enterprise;

public class Enterprise_Config {

}
