package enterprise;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import employee.Employee;

@RestController
public class Enterprise_Controller {
	
	@PostMapping("/api/catalog3")
	String postCatalog(@RequestBody List<Employee> data)
	{
		return "Data Posted" +data.get(0).getid()+ "" + data.get(0).getname();
		
		
	}
	
	@PutMapping("/api/catalog/{id}")
	String putCatalog(@PathVariable int id)
	{
		return "Data updated" +id;
	}
	
	@GetMapping("/api/catalog")
	@ResponseBody
	 // Method
		public ArrayList<String> getCatalog()
		{
		Employee e=new Employee();
		return e.getCatalogList();
		}
	
	@GetMapping("/api/catalog")
	@ResponseBody
	 // Method
		public ArrayList<String> getCatalog1()
		{
		Employee e=new Employee();
		return e.getCatalogList();
		}
}


 
