package enterprise;

public class Enterprise_Data {

}
