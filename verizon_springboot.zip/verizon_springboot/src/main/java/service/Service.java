package service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import employee.Employee;

@RestController
public class Service {
	@PostMapping("/api/catalog3")
	String postCatalog1(@RequestBody List<Employee> data)
	{
		return "Data Posted" +data.get(0).getid()+ "" + data.get(0).getname();
		
		
	}
	
	@PostMapping("/api/catalog3")
	String postCatalog2(@RequestBody List<Employee> data)
	{
		return "Data Posted" +data.get(0).getid()+ "" + data.get(0).getname();
		
		
	}
	

	@PutMapping("/api/catalog/{id}")
	String putCatalog(@PathVariable int id)
	{
		return "Data updated" +id;
	}
	

	@PutMapping("/api/catalog/{id}")
	String putCatalog1(@PathVariable int id)
	{
		return "Data updated" +id;
	}
	

	@PutMapping("/api/catalog/{id}")
	String putCatalog2(@PathVariable int id)
	{
		return "Data updated" +id;
	}

}
